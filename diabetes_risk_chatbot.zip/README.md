# 🩺 Diabetes Risk Assessment Assistant

A professional AI-powered healthcare chatbot built with Python and Streamlit.

## Features

- **Conversational Chatbot** — answers diabetes questions in plain language
- **Health Form** — collects 13 health metrics and calculates BMI automatically
- **Risk Assessment Engine** — evidence-based scoring (0–100) with Low / Moderate / High categories
- **Interactive Charts** — Plotly pie chart (risk probability) + line chart (recovery timeline)
- **PDF Report** — downloadable dark-themed health report via ReportLab
- **Learn Tab** — expandable diabetes education cards with dietary and exercise guides
- **Health Tips** — rotating daily health insights in the sidebar
- **Daily Checklist** — interactive self-care checklist

## Quick Start

```bash
# 1. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the app
streamlit run app.py
```

The app will open at **http://localhost:8501**

## Project Structure

```
diabetes_app/
├── app.py            # Main Streamlit application
├── pdf_report.py     # ReportLab PDF generator
├── requirements.txt  # Python dependencies
└── README.md
```

## How to Use

1. **Chat Tab** — Type `start` or ask any diabetes question
2. **Quick Form Tab** — Fill in your health metrics and click "Assess My Risk"
3. Results appear instantly with charts and recommendations
4. Click "Download PDF Health Report" for a shareable report

## Tech Stack

| Library | Purpose |
|---|---|
| Streamlit | Web UI framework |
| Plotly | Interactive charts |
| ReportLab | PDF generation |
| Scikit-Learn | ML model (extensible) |
| Pandas / NumPy | Data handling |

## Disclaimer

This tool is for **educational purposes only** and does not replace professional medical advice.
