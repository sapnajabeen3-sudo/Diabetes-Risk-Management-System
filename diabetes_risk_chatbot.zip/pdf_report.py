"""
pdf_report.py — Generates a professional PDF health report using ReportLab.
"""

from io import BytesIO
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT


# ── Colour palette ──────────────────────────────────────────────────────────
DARK_BG   = colors.HexColor("#050d1a")
DARK_CARD = colors.HexColor("#07131f")
NEON_BLUE = colors.HexColor("#00b4d8")
NEON_GRN  = colors.HexColor("#39ff14")
AMBER     = colors.HexColor("#ffd700")
RED_RISK  = colors.HexColor("#ff4444")
TEXT_MAIN = colors.HexColor("#e8f4fd")
TEXT_MUTE = colors.HexColor("#6b9ab8")
BORDER    = colors.HexColor("#0d2137")


def _risk_color(cls: str):
    return {"low": NEON_GRN, "mod": AMBER, "high": RED_RISK}.get(cls, NEON_BLUE)


def generate_pdf(
    data: dict,
    score: float,
    category: str,
    recs: dict,
) -> bytes:
    """
    Generates and returns a PDF health report as raw bytes.
    """
    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        leftMargin=20 * mm,
        rightMargin=20 * mm,
        topMargin=20 * mm,
        bottomMargin=20 * mm,
    )

    styles = getSampleStyleSheet()
    W = A4[0] - 40 * mm   # usable width

    # ── Custom styles ──────────────────────────────────────────────────────
    title_style = ParagraphStyle(
        "title", parent=styles["Title"],
        textColor=NEON_BLUE, fontSize=22, spaceAfter=4,
        fontName="Helvetica-Bold", alignment=TA_CENTER,
    )
    sub_style = ParagraphStyle(
        "sub", parent=styles["Normal"],
        textColor=TEXT_MUTE, fontSize=9, spaceAfter=2, alignment=TA_CENTER,
    )
    section_style = ParagraphStyle(
        "section", parent=styles["Normal"],
        textColor=NEON_BLUE, fontSize=11, spaceBefore=14, spaceAfter=6,
        fontName="Helvetica-Bold",
    )
    body_style = ParagraphStyle(
        "body", parent=styles["Normal"],
        textColor=TEXT_MAIN, fontSize=9, spaceAfter=4, leading=14,
    )
    warn_style = ParagraphStyle(
        "warn", parent=styles["Normal"],
        textColor=RED_RISK, fontSize=9, spaceAfter=4, leading=14,
    )
    good_style = ParagraphStyle(
        "good", parent=styles["Normal"],
        textColor=NEON_GRN, fontSize=9, spaceAfter=4, leading=14,
    )
    label_style = ParagraphStyle(
        "label", parent=styles["Normal"],
        textColor=TEXT_MUTE, fontSize=8,
    )
    value_style = ParagraphStyle(
        "value", parent=styles["Normal"],
        textColor=TEXT_MAIN, fontSize=10, fontName="Helvetica-Bold",
    )

    # ── Helper: coloured rule ──────────────────────────────────────────────
    def hr(colour=BORDER):
        return HRFlowable(width="100%", thickness=0.5, color=colour, spaceAfter=8)

    # ── Build flowable list ───────────────────────────────────────────────
    story = []

    # Header
    story.append(Paragraph("🩺 Diabetes Risk Assessment Report", title_style))
    story.append(Paragraph(
        f"Generated: {datetime.now().strftime('%B %d, %Y  %H:%M')}  ·  HealthGuard AI v2.0",
        sub_style,
    ))
    story.append(Spacer(1, 6))
    story.append(hr(NEON_BLUE))

    # ── Risk summary banner ───────────────────────────────────────────────
    cls = "low" if score < 35 else "mod" if score < 60 else "high"
    risk_col = _risk_color(cls)

    summary_data = [
        [
            Paragraph("RISK SCORE", label_style),
            Paragraph("RISK CATEGORY", label_style),
            Paragraph("BMI", label_style),
            Paragraph("ASSESSMENT DATE", label_style),
        ],
        [
            Paragraph(f"<b><font color='#{risk_col.hexval()[2:]}'>{score:.0f} / 100</font></b>", value_style),
            Paragraph(f"<b><font color='#{risk_col.hexval()[2:]}'>{category}</font></b>", value_style),
            Paragraph(f"<b>{data.get('bmi', '—')}</b>", value_style),
            Paragraph(datetime.now().strftime("%d %b %Y"), value_style),
        ],
    ]

    t = Table(summary_data, colWidths=[W / 4] * 4)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), DARK_CARD),
        ("TEXTCOLOR",  (0, 0), (-1, -1), TEXT_MAIN),
        ("ALIGN",      (0, 0), (-1, -1), "CENTER"),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [DARK_CARD]),
        ("BOX",        (0, 0), (-1, -1), 1, BORDER),
        ("INNERGRID",  (0, 0), (-1, -1), 0.5, BORDER),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
    ]))
    story.append(t)
    story.append(Spacer(1, 12))

    # ── Personal health details ───────────────────────────────────────────
    story.append(Paragraph("Personal Health Details", section_style))
    story.append(hr())

    detail_rows = [
        ["Age", f"{data.get('age', '—')} years",
         "Gender", data.get("gender", "—")],
        ["Height", f"{data.get('height', '—')} cm",
         "Weight", f"{data.get('weight', '—')} kg"],
        ["BMI", f"{data.get('bmi', '—')} kg/m²",
         "Fasting Glucose", f"{data.get('glucose', '—')} mg/dL"],
        ["Blood Pressure (D)", f"{data.get('blood_pressure', '—')} mmHg",
         "Sleep", f"{data.get('sleep', '—')} hours/night"],
        ["Water Intake", f"{data.get('water', '—')} L/day",
         "Stress Level", f"{data.get('stress', '—')} / 10"],
        ["Family History", data.get("family_history", "—"),
         "Smoking", data.get("smoking", "—")],
        ["Physical Activity", data.get("activity", "—"),
         "", ""],
    ]

    cell_style = ParagraphStyle("cell", fontSize=9, textColor=TEXT_MAIN, leading=12)
    lbl_style2 = ParagraphStyle("lbl2", fontSize=8, textColor=TEXT_MUTE, leading=12)

    tbl_data = []
    for row in detail_rows:
        tbl_data.append([
            Paragraph(row[0], lbl_style2),
            Paragraph(row[1], cell_style),
            Paragraph(row[2], lbl_style2),
            Paragraph(row[3], cell_style),
        ])

    dt = Table(tbl_data, colWidths=[W * 0.2, W * 0.3, W * 0.2, W * 0.3])
    dt.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), DARK_CARD),
        ("BOX",        (0, 0), (-1, -1), 1, BORDER),
        ("INNERGRID",  (0, 0), (-1, -1), 0.5, BORDER),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(dt)
    story.append(Spacer(1, 12))

    # ── Recommendations ───────────────────────────────────────────────────
    if recs.get("warnings"):
        story.append(Paragraph("Health Warnings", section_style))
        story.append(hr(RED_RISK))
        for w in recs["warnings"]:
            story.append(Paragraph(f"• {w}", warn_style))
        story.append(Spacer(1, 6))

    if recs.get("actions"):
        story.append(Paragraph("Recommended Actions", section_style))
        story.append(hr(NEON_BLUE))
        for a in recs["actions"]:
            story.append(Paragraph(f"• {a}", body_style))
        story.append(Spacer(1, 6))

    if recs.get("positives"):
        story.append(Paragraph("Positive Health Indicators", section_style))
        story.append(hr(NEON_GRN))
        for p in recs["positives"]:
            story.append(Paragraph(f"• {p}", good_style))
        story.append(Spacer(1, 6))

    # ── Improvement timeline ───────────────────────────────────────────────
    story.append(Paragraph("Estimated Health Improvement Timeline", section_style))
    story.append(hr())

    if category == "Low Risk":
        timeline = [("Month 1", "15%"), ("Month 3", "30%"), ("Month 6", "52%"), ("Month 12", "70%")]
        note = "With consistent healthy habits, you can maintain and further improve your low-risk status."
    elif category == "Moderate Risk":
        timeline = [("Month 1", "8%"), ("Month 3", "22%"), ("Month 6", "42%"), ("Month 12", "65%")]
        note = "Sustained lifestyle changes over 3–6 months will significantly reduce your risk category."
    else:
        timeline = [("Month 1", "5%"), ("Month 3", "15%"), ("Month 6", "32%"), ("Month 12", "58%")]
        note = "With medical support and lifestyle changes, meaningful improvement is achievable within 12 months."

    story.append(Paragraph(note, body_style))
    tl_header = [Paragraph(m, lbl_style2) for m, _ in timeline]
    tl_values  = [Paragraph(v, ParagraphStyle("tl", fontSize=12, fontName="Helvetica-Bold",
                                               textColor=NEON_BLUE, alignment=TA_CENTER)) for _, v in timeline]
    tl_tbl = Table([tl_header, tl_values], colWidths=[W / 4] * 4)
    tl_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), DARK_CARD),
        ("ALIGN",      (0, 0), (-1, -1), "CENTER"),
        ("BOX",        (0, 0), (-1, -1), 1, BORDER),
        ("INNERGRID",  (0, 0), (-1, -1), 0.5, BORDER),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
    ]))
    story.append(tl_tbl)
    story.append(Spacer(1, 16))

    # ── Disclaimer ────────────────────────────────────────────────────────
    story.append(hr())
    story.append(Paragraph(
        "⚕️ Disclaimer: This report is generated for educational purposes only and does not "
        "constitute medical advice. Please consult a qualified healthcare professional before "
        "making any health decisions.",
        ParagraphStyle("disc", parent=styles["Normal"], fontSize=8,
                       textColor=TEXT_MUTE, alignment=TA_CENTER, leading=12),
    ))

    # ── Build PDF ─────────────────────────────────────────────────────────
    def _bg(canvas, doc):
        canvas.saveState()
        canvas.setFillColor(DARK_BG)
        canvas.rect(0, 0, A4[0], A4[1], fill=True, stroke=False)
        canvas.restoreState()

    doc.build(story, onFirstPage=_bg, onLaterPages=_bg)
    return buf.getvalue()
