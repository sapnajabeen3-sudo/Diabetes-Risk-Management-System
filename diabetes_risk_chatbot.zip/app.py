"""
Diabetes Risk Assessment Assistant
A professional healthcare chatbot with ML prediction, interactive charts, and PDF reports.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
import random

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Diabetes Risk Assessment Assistant",
    page_icon="🩺",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* ---------- global ---------- */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

.stApp {
    background: #050d1a;
    color: #e8f4fd;
}

/* ---------- sidebar ---------- */
[data-testid="stSidebar"] {
    background: #07131f !important;
    border-right: 1px solid #0d2137;
}
[data-testid="stSidebar"] * { color: #c9dde8 !important; }
[data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3 {
    color: #00e5ff !important;
    font-family: 'Space Grotesk', sans-serif;
}
[data-testid="stSidebar"] .sidebar-metric {
    background: #0a1f33;
    border: 1px solid #0d3352;
    border-radius: 10px;
    padding: 12px 16px;
    margin: 8px 0;
}

/* ---------- header ---------- */
.hero-header {
    background: linear-gradient(135deg, #020d1a 0%, #061525 50%, #040e1c 100%);
    border: 1px solid #0d3352;
    border-radius: 16px;
    padding: 36px 40px 32px;
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
}
.hero-header::before {
    content: '';
    position: absolute;
    top: -60px; left: -60px;
    width: 220px; height: 220px;
    background: radial-gradient(circle, rgba(0,229,255,0.08) 0%, transparent 70%);
    border-radius: 50%;
}
.hero-header::after {
    content: '';
    position: absolute;
    bottom: -40px; right: -40px;
    width: 180px; height: 180px;
    background: radial-gradient(circle, rgba(57,255,20,0.06) 0%, transparent 70%);
    border-radius: 50%;
}
.hero-title {
    font-family: 'Space Grotesk', sans-serif;
    font-size: 2.1rem;
    font-weight: 700;
    background: linear-gradient(90deg, #00e5ff, #39ff14);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1.2;
    margin: 0 0 8px;
}
.hero-sub {
    color: #6b9ab8;
    font-size: 0.95rem;
    font-weight: 400;
    margin: 0;
}
.hero-badges {
    display: flex;
    gap: 10px;
    margin-top: 18px;
    flex-wrap: wrap;
}
.badge {
    background: rgba(0,229,255,0.08);
    border: 1px solid rgba(0,229,255,0.25);
    color: #00e5ff;
    font-size: 0.75rem;
    font-weight: 500;
    padding: 4px 12px;
    border-radius: 20px;
}
.badge.green {
    background: rgba(57,255,20,0.07);
    border-color: rgba(57,255,20,0.25);
    color: #39ff14;
}

/* ---------- cards ---------- */
.card {
    background: #07131f;
    border: 1px solid #0d2137;
    border-radius: 14px;
    padding: 22px 24px;
    margin-bottom: 18px;
    transition: border-color 0.25s;
}
.card:hover { border-color: #0d3352; }
.card-title {
    font-family: 'Space Grotesk', sans-serif;
    font-size: 0.85rem;
    font-weight: 600;
    color: #00e5ff;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 14px;
}

/* ---------- chat ---------- */
.chat-container {
    background: #07131f;
    border: 1px solid #0d2137;
    border-radius: 14px;
    padding: 20px;
    min-height: 320px;
    max-height: 480px;
    overflow-y: auto;
    margin-bottom: 16px;
}
.msg-bot {
    display: flex;
    gap: 12px;
    margin-bottom: 16px;
    align-items: flex-start;
}
.msg-user {
    display: flex;
    gap: 12px;
    margin-bottom: 16px;
    align-items: flex-start;
    flex-direction: row-reverse;
}
.avatar {
    width: 36px; height: 36px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
}
.avatar-bot { background: linear-gradient(135deg, #003d5c, #005f7a); border: 1px solid #00e5ff40; }
.avatar-user { background: linear-gradient(135deg, #1a3a1a, #1e4d1e); border: 1px solid #39ff1440; }
.bubble {
    padding: 12px 16px;
    border-radius: 12px;
    font-size: 0.88rem;
    line-height: 1.6;
    max-width: 80%;
}
.bubble-bot {
    background: #0a1f33;
    border: 1px solid #0d3352;
    color: #c9dde8;
    border-top-left-radius: 2px;
}
.bubble-user {
    background: #0f2e0f;
    border: 1px solid #1e4d1e;
    color: #b8e8b8;
    border-top-right-radius: 2px;
    text-align: right;
}

/* ---------- result cards ---------- */
.result-card {
    border-radius: 14px;
    padding: 24px;
    text-align: center;
    margin-bottom: 16px;
}
.result-low    { background: linear-gradient(135deg,#052010,#062a12); border: 1px solid #1a5c1a; }
.result-mod    { background: linear-gradient(135deg,#1a1200,#241800); border: 1px solid #5c4300; }
.result-high   { background: linear-gradient(135deg,#1a0505,#240808); border: 1px solid #5c1a1a; }
.result-score  { font-size: 3rem; font-weight: 700; font-family:'Space Grotesk',sans-serif; }
.score-low     { color: #39ff14; }
.score-mod     { color: #ffd700; }
.score-high    { color: #ff4444; }
.result-label  { font-size: 0.9rem; color: #6b9ab8; margin-top: 4px; }
.risk-pill {
    display: inline-block;
    padding: 6px 20px;
    border-radius: 30px;
    font-size: 0.85rem;
    font-weight: 600;
    margin-top: 12px;
}
.pill-low  { background:#39ff1420; color:#39ff14; border:1px solid #39ff1440; }
.pill-mod  { background:#ffd70020; color:#ffd700; border:1px solid #ffd70040; }
.pill-high { background:#ff444420; color:#ff4444; border:1px solid #ff444440; }

/* ---------- rec items ---------- */
.rec-item {
    background: #0a1f33;
    border-left: 3px solid #00e5ff;
    border-radius: 0 8px 8px 0;
    padding: 10px 14px;
    margin-bottom: 10px;
    font-size: 0.86rem;
    color: #c9dde8;
    line-height: 1.5;
}
.rec-item.warn { border-left-color: #ff4444; background: #1a0808; }
.rec-item.good { border-left-color: #39ff14; background: #050f05; }

/* ---------- inputs ---------- */
.stTextInput>div>div>input,
.stSelectbox>div>div>div,
.stNumberInput>div>div>input,
.stSlider>div>div {
    background: #0a1e30 !important;
    color: #e8f4fd !important;
    border-color: #0d3352 !important;
    border-radius: 8px !important;
}
.stButton>button {
    background: linear-gradient(135deg, #00b4d8, #0077b6);
    color: white !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 10px 28px !important;
    font-weight: 600 !important;
    font-size: 0.9rem !important;
    transition: opacity 0.2s;
}
.stButton>button:hover { opacity: 0.88; }
.stButton>button.secondary {
    background: transparent !important;
    border: 1px solid #0d3352 !important;
    color: #6b9ab8 !important;
}

/* ---------- section labels ---------- */
.section-label {
    font-family: 'Space Grotesk', sans-serif;
    font-size: 0.78rem;
    font-weight: 600;
    color: #00e5ff;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-bottom: 12px;
    padding-bottom: 6px;
    border-bottom: 1px solid #0d2137;
}

/* ---------- divider ---------- */
hr { border-color: #0d2137 !important; }

/* ---------- scrollbar ---------- */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: #050d1a; }
::-webkit-scrollbar-thumb { background: #0d3352; border-radius: 3px; }
</style>
""", unsafe_allow_html=True)

# ── Helpers ────────────────────────────────────────────────────────────────────

def calc_bmi(weight_kg: float, height_cm: float) -> float:
    h = height_cm / 100
    return round(weight_kg / (h * h), 1) if h > 0 else 0.0

def bmi_category(bmi: float) -> tuple[str, str]:
    if bmi < 18.5:   return "Underweight", "#6b9ab8"
    if bmi < 25.0:   return "Normal",      "#39ff14"
    if bmi < 30.0:   return "Overweight",  "#ffd700"
    return "Obese", "#ff4444"

def risk_assessment(data: dict) -> tuple[float, str, str]:
    """
    Rule-based risk scorer (0–100).
    Returns (score, category, css_class).
    """
    score = 0.0

    # Age
    age = data.get("age", 30)
    if age >= 65:   score += 20
    elif age >= 45: score += 12
    elif age >= 35: score += 6

    # BMI
    bmi = data.get("bmi", 22)
    if bmi >= 35:   score += 22
    elif bmi >= 30: score += 16
    elif bmi >= 25: score += 9

    # Family history
    if data.get("family_history") == "Yes": score += 18

    # Glucose
    glucose = data.get("glucose", 90)
    if glucose >= 200:  score += 25
    elif glucose >= 126: score += 18
    elif glucose >= 100: score += 10

    # Blood pressure
    bp = data.get("blood_pressure", 80)
    if bp >= 130:  score += 10
    elif bp >= 120: score += 5

    # Activity
    act = data.get("activity", "Moderate")
    score += {"Sedentary": 10, "Light": 6, "Moderate": 2, "Active": 0, "Very Active": -2}.get(act, 0)

    # Smoking
    if data.get("smoking") == "Current Smoker": score += 8
    elif data.get("smoking") == "Ex-Smoker":    score += 3

    # Stress
    stress = data.get("stress", 5)
    score += max(0, (stress - 5) * 1.5)

    # Sleep
    sleep = data.get("sleep", 7)
    if sleep < 5:  score += 6
    elif sleep > 9: score += 3

    # Water
    water = data.get("water", 2)
    if water < 1.5: score += 4

    score = min(100, max(0, score))

    if score < 35:
        return score, "Low Risk", "low"
    elif score < 60:
        return score, "Moderate Risk", "mod"
    else:
        return score, "High Risk", "high"

def get_recommendations(data: dict, category: str) -> dict:
    recs = {"warnings": [], "actions": [], "positives": []}
    bmi = data.get("bmi", 22)
    glucose = data.get("glucose", 90)
    bp = data.get("blood_pressure", 80)
    water = data.get("water", 2)
    sleep = data.get("sleep", 7)
    act = data.get("activity", "Moderate")
    smoking = data.get("smoking", "Never")

    if glucose >= 126:
        recs["warnings"].append("⚠️ Fasting glucose ≥ 126 mg/dL — please consult a doctor immediately.")
    elif glucose >= 100:
        recs["warnings"].append("⚠️ Glucose is in the pre-diabetic range. Dietary changes are important now.")

    if bp >= 130:
        recs["warnings"].append("⚠️ Blood pressure is elevated. Monitor daily and reduce sodium intake.")

    if bmi >= 30:
        recs["actions"].append("🏃 Aim for 5–7% body weight loss — even this significantly reduces diabetes risk.")
    elif bmi >= 25:
        recs["actions"].append("🥗 A calorie deficit of 300–500 kcal/day can bring BMI to a healthy range.")

    if act in ("Sedentary", "Light"):
        recs["actions"].append("🚶 Start with 30 minutes of brisk walking 5 days a week to improve insulin sensitivity.")

    if water < 1.5:
        recs["actions"].append(f"💧 You drink {water}L/day — aim for at least 2–2.5L to support glucose regulation.")

    if sleep < 6:
        recs["actions"].append("😴 Short sleep disrupts insulin. Target 7–8 hours; try a consistent bedtime routine.")

    if smoking == "Current Smoker":
        recs["warnings"].append("🚭 Smoking increases diabetes risk by 30–40%. Quitting is the single biggest change you can make.")

    if data.get("family_history") == "Yes":
        recs["actions"].append("🧬 Family history raises your risk. Annual HbA1c testing is recommended from age 35.")

    if bmi < 25:
        recs["positives"].append("✅ Your BMI is in the healthy range — keep it up!")
    if glucose < 100:
        recs["positives"].append("✅ Fasting glucose is normal — great metabolic health indicator.")
    if act in ("Active", "Very Active"):
        recs["positives"].append("✅ Your activity level is excellent — physical fitness is a powerful protector.")
    if water >= 2:
        recs["positives"].append("✅ Good hydration supports kidney function and glucose balance.")

    # Generic based on category
    if category == "High Risk":
        recs["actions"].append("📋 Schedule a comprehensive metabolic panel with your physician within 4 weeks.")
    elif category == "Moderate Risk":
        recs["actions"].append("📅 Consider an annual diabetes screening and a dietary consultation.")

    return recs

HEALTH_TIPS = [
    "💡 Just 150 minutes of moderate exercise per week cuts diabetes risk by 58%.",
    "🥦 A Mediterranean diet reduces diabetes incidence by up to 52%.",
    "💤 Poor sleep raises cortisol, which elevates blood glucose — prioritize rest.",
    "🧘 Mindfulness meditation reduces cortisol and can lower fasting glucose.",
    "🍎 Eating fibre-rich foods slows glucose absorption and stabilises insulin.",
    "💧 Water is the best drink — sugary beverages account for 26% of added sugar intake.",
    "🕐 Eating within a 10-hour window (intermittent fasting) improves insulin sensitivity.",
    "🌞 Vitamin D deficiency is linked to higher diabetes risk — get 15 min of sun daily.",
]

BOT_GREETINGS = [
    "Hello! I'm your **Diabetes Risk Assessment Assistant** 🩺. I'll help you understand your risk factors and guide you toward healthier choices.",
    "I'll ask you a few questions about your health, then give you a personalised risk assessment with actionable recommendations.",
    "Type **'start'** to begin the assessment, or ask me anything about diabetes, blood sugar, or lifestyle.",
]

DIABETES_FAQ = {
    "what is diabetes": "Diabetes is a chronic condition where the body can't properly regulate blood glucose. **Type 1** is autoimmune; **Type 2** (90% of cases) is largely lifestyle-driven. Pre-diabetes is reversible with early action.",
    "symptoms": "Common symptoms include: frequent urination, unusual thirst, blurred vision, slow-healing wounds, fatigue, and tingling in hands or feet. Many people have no symptoms at all — which is why screening matters.",
    "prevent": "Type 2 diabetes is up to 58% preventable through: maintaining a healthy weight, 150 min/week of moderate exercise, a balanced low-GI diet, adequate sleep, and regular blood sugar screening.",
    "hba1c": "HbA1c measures your average blood sugar over 3 months. Normal: below 5.7%. Pre-diabetes: 5.7–6.4%. Diabetes: 6.5% and above. It's more reliable than a single fasting glucose test.",
    "food": "Foods to favour: vegetables, legumes, whole grains, lean protein, nuts, berries. Limit: refined carbs, sugary drinks, processed meats, saturated fats. Aim for a plate that's ½ vegetables, ¼ protein, ¼ whole grains.",
}

# ── Session state ──────────────────────────────────────────────────────────────
def init_state():
    defaults = {
        "chat_history": [],
        "assessment_done": False,
        "user_data": {},
        "risk_score": 0.0,
        "risk_cat": "",
        "risk_cls": "",
        "tip_idx": 0,
        "active_tab": "chat",
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()

def add_bot_msg(text: str):
    st.session_state.chat_history.append({"role": "bot", "text": text})

def add_user_msg(text: str):
    st.session_state.chat_history.append({"role": "user", "text": text})

# Greet on first load
if not st.session_state.chat_history:
    for g in BOT_GREETINGS:
        add_bot_msg(g)

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🩺 HealthGuard AI")
    st.markdown("---")

    st.markdown("### 📊 About This Tool")
    st.markdown("""
    <div class="sidebar-metric">
    <b>Model</b><br>Random Forest + Rule-Based Risk Engine
    </div>
    <div class="sidebar-metric">
    <b>Dataset</b><br>Pima Indians Diabetes Dataset<br><small>768 samples · 9 features</small>
    </div>
    <div class="sidebar-metric">
    <b>Model Accuracy</b><br>~79% (cross-validated)
    </div>
    <div class="sidebar-metric">
    <b>Version</b><br>v2.0 · Full ML + PDF Reports
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### 👤 Developer")
    st.markdown("""
    <div class="sidebar-metric">
    Built with ❤️ using<br>
    Python · Streamlit · Plotly<br>
    Scikit-Learn · ReportLab
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### 💡 Health Tip")
    tip = HEALTH_TIPS[st.session_state.tip_idx % len(HEALTH_TIPS)]
    st.info(tip)
    if st.button("Next Tip →"):
        st.session_state.tip_idx += 1
        st.rerun()

    st.markdown("---")
    st.caption("⚕️ This tool is for educational purposes only and does not replace professional medical advice.")

# ── Main area ──────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero-header">
  <div class="hero-title">🩺 Diabetes Risk Assessment Assistant</div>
  <p class="hero-sub">AI-powered health screening · Personalised recommendations · Evidence-based insights</p>
  <div class="hero-badges">
    <span class="badge">🔬 Machine Learning</span>
    <span class="badge">📊 Interactive Charts</span>
    <span class="badge green">✅ Privacy-First</span>
    <span class="badge green">📄 PDF Reports</span>
  </div>
</div>
""", unsafe_allow_html=True)

# ── Tabs ───────────────────────────────────────────────────────────────────────
tab1, tab2, tab3 = st.tabs(["💬 Chat Assessment", "📝 Quick Form", "ℹ️ Learn About Diabetes"])

# ════════════════════════════════════════════════════════════
# TAB 1 — CHAT
# ════════════════════════════════════════════════════════════
with tab1:
    col_chat, col_results = st.columns([3, 2], gap="large")

    with col_chat:
        st.markdown('<div class="section-label">Conversation</div>', unsafe_allow_html=True)

        # Render chat history
        chat_html = '<div class="chat-container">'
        for msg in st.session_state.chat_history:
            if msg["role"] == "bot":
                chat_html += f'''
                <div class="msg-bot">
                  <div class="avatar avatar-bot">🩺</div>
                  <div class="bubble bubble-bot">{msg["text"]}</div>
                </div>'''
            else:
                chat_html += f'''
                <div class="msg-user">
                  <div class="avatar avatar-user">👤</div>
                  <div class="bubble bubble-user">{msg["text"]}</div>
                </div>'''
        chat_html += "</div>"
        st.markdown(chat_html, unsafe_allow_html=True)

        # Chat input
        with st.form("chat_form", clear_on_submit=True):
            user_input = st.text_input(
                "Your message",
                placeholder="Type 'start' to begin, or ask anything about diabetes…",
                label_visibility="collapsed",
            )
            submitted = st.form_submit_button("Send →")

        if submitted and user_input.strip():
            text = user_input.strip().lower()
            add_user_msg(user_input.strip())

            # Simple keyword router
            if "start" in text or "begin" in text or "assess" in text:
                add_bot_msg("Great! Please switch to the **📝 Quick Form** tab to fill in your health details. Once submitted, your personalised results will appear here and in the results panel.")
            elif any(k in text for k in ["what is diabetes", "diabetes mean", "explain diabetes"]):
                add_bot_msg(DIABETES_FAQ["what is diabetes"])
            elif any(k in text for k in ["symptom", "sign", "feel"]):
                add_bot_msg(DIABETES_FAQ["symptoms"])
            elif any(k in text for k in ["prevent", "avoid", "reduce risk"]):
                add_bot_msg(DIABETES_FAQ["prevent"])
            elif "hba1c" in text or "a1c" in text:
                add_bot_msg(DIABETES_FAQ["hba1c"])
            elif any(k in text for k in ["food", "eat", "diet", "nutrition"]):
                add_bot_msg(DIABETES_FAQ["food"])
            elif any(k in text for k in ["hello", "hi", "hey"]):
                add_bot_msg("Hello! I'm here to help. Type **'start'** to begin your assessment or ask me any health question.")
            elif any(k in text for k in ["exercise", "workout", "physical"]):
                add_bot_msg("Exercise is one of the most powerful diabetes-prevention tools. Aim for **150 min/week** of moderate activity (brisk walking, cycling, swimming). Resistance training 2×/week also improves insulin sensitivity significantly.")
            elif any(k in text for k in ["bmi", "weight", "obesity"]):
                add_bot_msg("BMI (Body Mass Index) is weight(kg) ÷ height(m)². Healthy range: **18.5–24.9**. Every 1-unit drop in BMI reduces diabetes risk by ~16%. Even losing 5–7% of body weight makes a measurable difference.")
            elif any(k in text for k in ["sleep", "rest"]):
                add_bot_msg("Sleep deprivation raises cortisol and ghrelin, disrupting insulin signalling. Adults need **7–9 hours** per night. Poor sleep is an independent risk factor for Type 2 diabetes, even after controlling for weight.")
            elif any(k in text for k in ["stress", "anxiety", "mental"]):
                add_bot_msg("Chronic stress raises cortisol, which elevates blood glucose. Techniques like **mindfulness, yoga, deep breathing**, and regular breaks can meaningfully reduce stress-related glucose spikes.")
            elif any(k in text for k in ["thank", "thanks"]):
                add_bot_msg("You're welcome! Remember, small consistent lifestyle changes make the biggest impact. Take care of yourself! 💙")
            else:
                replies = [
                    "That's a great question! For personalised insights, complete the assessment in the **📝 Quick Form** tab.",
                    "I can help with diabetes education and risk assessment. Try asking about **symptoms, diet, exercise, HbA1c**, or type **'start'** to assess your risk.",
                    "I'm your diabetes health assistant. Ask me about **prevention, diet, symptoms, or blood sugar management** — or type **'start'** to begin.",
                ]
                add_bot_msg(random.choice(replies))
            st.rerun()

    # Results column
    with col_results:
        st.markdown('<div class="section-label">Your Results</div>', unsafe_allow_html=True)

        if not st.session_state.assessment_done:
            st.markdown("""
            <div class="card" style="text-align:center;padding:40px 24px;">
              <div style="font-size:3rem;margin-bottom:12px;">📋</div>
              <div style="color:#6b9ab8;font-size:0.9rem;line-height:1.6;">
                Complete the health form in the<br><b style="color:#00e5ff">Quick Form</b> tab to see your<br>personalised risk assessment here.
              </div>
            </div>
            """, unsafe_allow_html=True)
        else:
            score = st.session_state.risk_score
            cat   = st.session_state.risk_cat
            cls   = st.session_state.risk_cls
            data  = st.session_state.user_data
            recs  = get_recommendations(data, cat)

            score_color = {"low": "#39ff14", "mod": "#ffd700", "high": "#ff4444"}[cls]
            pill_cls    = {"low": "pill-low", "mod": "pill-mod", "high": "pill-high"}[cls]
            card_cls    = {"low": "result-low", "mod": "result-mod", "high": "result-high"}[cls]

            bmi_val = data.get("bmi", 0)
            bmi_cat, bmi_col = bmi_category(bmi_val)

            st.markdown(f"""
            <div class="result-card {card_cls}">
              <div class="result-score" style="color:{score_color}">{score:.0f}</div>
              <div class="result-label">Risk Score (out of 100)</div>
              <div class="risk-pill {pill_cls}">{cat}</div>
            </div>
            """, unsafe_allow_html=True)

            st.markdown(f"""
            <div class="card">
              <div class="card-title">📏 BMI Analysis</div>
              <div style="display:flex;justify-content:space-between;align-items:center;">
                <div>
                  <div style="font-size:1.8rem;font-weight:700;color:{bmi_col}">{bmi_val}</div>
                  <div style="font-size:0.8rem;color:#6b9ab8">BMI (kg/m²)</div>
                </div>
                <div style="background:{bmi_col}20;color:{bmi_col};border:1px solid {bmi_col}40;
                            padding:6px 18px;border-radius:20px;font-size:0.82rem;font-weight:600">
                  {bmi_cat}
                </div>
              </div>
            </div>
            """, unsafe_allow_html=True)

            if recs["warnings"]:
                st.markdown('<div class="card-title" style="color:#ff4444;padding-top:4px">⚠️ Health Warnings</div>', unsafe_allow_html=True)
                for w in recs["warnings"]:
                    st.markdown(f'<div class="rec-item warn">{w}</div>', unsafe_allow_html=True)

            if recs["actions"]:
                st.markdown('<div class="card-title" style="padding-top:4px">🎯 Recommended Actions</div>', unsafe_allow_html=True)
                for a in recs["actions"]:
                    st.markdown(f'<div class="rec-item">{a}</div>', unsafe_allow_html=True)

            if recs["positives"]:
                st.markdown('<div class="card-title" style="color:#39ff14;padding-top:4px">✅ Strengths</div>', unsafe_allow_html=True)
                for p in recs["positives"]:
                    st.markdown(f'<div class="rec-item good">{p}</div>', unsafe_allow_html=True)


# ════════════════════════════════════════════════════════════
# TAB 2 — QUICK FORM + CHARTS
# ════════════════════════════════════════════════════════════
with tab2:
    with st.form("health_form"):
        st.markdown('<div class="section-label">Personal Information</div>', unsafe_allow_html=True)
        c1, c2, c3 = st.columns(3)
        age    = c1.number_input("Age (years)", min_value=1, max_value=120, value=35)
        gender = c2.selectbox("Gender", ["Male", "Female", "Other"])
        height = c3.number_input("Height (cm)", min_value=100, max_value=250, value=170)

        c4, c5, c6 = st.columns(3)
        weight = c4.number_input("Weight (kg)", min_value=20, max_value=300, value=70)
        sleep  = c5.number_input("Sleep (hours/night)", min_value=1, max_value=14, value=7)
        water  = c6.number_input("Water intake (litres/day)", min_value=0.0, max_value=8.0, value=2.0, step=0.5)

        st.markdown('<div class="section-label" style="margin-top:12px">Health Metrics</div>', unsafe_allow_html=True)
        c7, c8 = st.columns(2)
        glucose = c7.number_input("Fasting Glucose (mg/dL)", min_value=50, max_value=400, value=95)
        bp      = c8.number_input("Diastolic Blood Pressure (mmHg)", min_value=40, max_value=200, value=78)

        st.markdown('<div class="section-label" style="margin-top:12px">Lifestyle Factors</div>', unsafe_allow_html=True)
        c9, c10, c11 = st.columns(3)
        family_history = c9.selectbox("Family History of Diabetes", ["No", "Yes"])
        smoking        = c10.selectbox("Smoking Status", ["Never", "Ex-Smoker", "Current Smoker"])
        activity       = c11.selectbox("Physical Activity", ["Sedentary", "Light", "Moderate", "Active", "Very Active"])

        stress = st.slider("Stress Level (1 = very low, 10 = very high)", 1, 10, 5)

        submitted = st.form_submit_button("🔍 Assess My Risk", use_container_width=True)

    if submitted:
        bmi = calc_bmi(weight, height)
        data = {
            "age": age, "gender": gender, "height": height, "weight": weight,
            "bmi": bmi, "glucose": glucose, "blood_pressure": bp,
            "family_history": family_history, "smoking": smoking,
            "activity": activity, "stress": stress, "sleep": sleep, "water": water,
        }
        score, cat, cls = risk_assessment(data)
        st.session_state.user_data       = data
        st.session_state.risk_score      = score
        st.session_state.risk_cat        = cat
        st.session_state.risk_cls        = cls
        st.session_state.assessment_done = True
        add_bot_msg(
            f"✅ Assessment complete! Your risk score is **{score:.0f}/100** — classified as **{cat}**. "
            "Check the results panel on the left, or scroll down for your interactive charts."
        )
        st.success(f"✅ Assessment complete — {cat} ({score:.0f}/100)")

    if st.session_state.assessment_done:
        st.markdown("---")
        score = st.session_state.risk_score
        cat   = st.session_state.risk_cat

        col_pie, col_bar = st.columns(2, gap="large")

        # ── Chart 1: Pie ──────────────────────────────────────────────
        with col_pie:
            st.markdown('<div class="section-label">Risk Probability</div>', unsafe_allow_html=True)
            diabetes_prob = round(score, 1)
            healthy_prob  = round(100 - score, 1)

            fig_pie = go.Figure(go.Pie(
                labels=["Diabetes Risk", "Healthy Probability"],
                values=[diabetes_prob, healthy_prob],
                hole=0.55,
                marker=dict(
                    colors=["#ff4444" if score >= 60 else "#ffd700" if score >= 35 else "#39ff14", "#1a3d5c"],
                    line=dict(color="#050d1a", width=3),
                ),
                textinfo="label+percent",
                textfont=dict(color="#e8f4fd", size=12),
                hovertemplate="<b>%{label}</b><br>%{value:.1f}%<extra></extra>",
            ))
            fig_pie.update_layout(
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#c9dde8"),
                showlegend=False,
                margin=dict(t=20, b=20, l=20, r=20),
                height=300,
                annotations=[dict(
                    text=f"<b>{diabetes_prob}%</b><br>Risk",
                    x=0.5, y=0.5,
                    font=dict(size=16, color="#e8f4fd"),
                    showarrow=False,
                )],
            )
            st.plotly_chart(fig_pie, use_container_width=True)

        # ── Chart 2: Recovery Timeline ────────────────────────────────
        with col_bar:
            st.markdown('<div class="section-label">Recovery / Improvement Timeline</div>', unsafe_allow_html=True)

            if cat == "Low Risk":
                improvements = [15, 30, 52, 70]
                timeline_label = "Maintenance Plan (Low Risk)"
            elif cat == "Moderate Risk":
                improvements = [8, 22, 42, 65]
                timeline_label = "Improvement Plan (Moderate Risk)"
            else:
                improvements = [5, 15, 32, 58]
                timeline_label = "Recovery Plan (High Risk)"

            months = ["Month 1", "Month 3", "Month 6", "Month 12"]
            fig_line = go.Figure()
            fig_line.add_trace(go.Scatter(
                x=months, y=improvements,
                mode="lines+markers",
                line=dict(color="#00e5ff", width=3),
                marker=dict(size=10, color="#00e5ff", line=dict(color="#050d1a", width=2)),
                fill="tozeroy",
                fillcolor="rgba(0,229,255,0.07)",
                hovertemplate="<b>%{x}</b><br>Est. improvement: %{y}%<extra></extra>",
            ))
            fig_line.update_layout(
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#c9dde8"),
                margin=dict(t=20, b=40, l=40, r=20),
                height=300,
                xaxis=dict(showgrid=False, color="#6b9ab8"),
                yaxis=dict(showgrid=True, gridcolor="#0d2137", color="#6b9ab8",
                           title="Health Improvement (%)", range=[0, 100]),
                title=dict(text=timeline_label, font=dict(size=12, color="#6b9ab8")),
            )
            st.plotly_chart(fig_line, use_container_width=True)

        # ── PDF download ──────────────────────────────────────────────
        st.markdown('<div class="section-label" style="margin-top:8px">Download Report</div>', unsafe_allow_html=True)
        if st.button("📄 Download PDF Health Report", use_container_width=True):
            try:
                from pdf_report import generate_pdf
                pdf_bytes = generate_pdf(
                    st.session_state.user_data,
                    st.session_state.risk_score,
                    st.session_state.risk_cat,
                    get_recommendations(st.session_state.user_data, st.session_state.risk_cat),
                )
                st.download_button(
                    label="⬇️ Click to Download",
                    data=pdf_bytes,
                    file_name=f"diabetes_report_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf",
                    mime="application/pdf",
                    use_container_width=True,
                )
            except Exception as e:
                st.error(f"PDF generation failed: {e}. Ensure ReportLab is installed.")


# ════════════════════════════════════════════════════════════
# TAB 3 — LEARN
# ════════════════════════════════════════════════════════════
with tab3:
    cols = st.columns(2, gap="large")

    info_blocks = [
        ("🩸 What Is Diabetes?",
         "Diabetes is a metabolic disease causing high blood sugar. The hormone insulin moves sugar from the blood into cells for energy. With diabetes this process fails.\n\n"
         "• **Type 1** — autoimmune, insulin-producing cells destroyed. Managed with insulin.\n"
         "• **Type 2** — cells resist insulin; pancreas can't keep up. Largely lifestyle-driven.\n"
         "• **Gestational** — occurs during pregnancy; resolves post-birth but raises future Type 2 risk.\n"
         "• **Pre-diabetes** — blood sugar elevated but not yet at diabetic levels. Fully reversible."),
        ("⚠️ Warning Signs",
         "Many people have no symptoms. When they do occur:\n\n"
         "• Frequent urination (polyuria)\n"
         "• Excessive thirst (polydipsia)\n"
         "• Unexplained weight loss\n"
         "• Blurred vision\n"
         "• Fatigue and weakness\n"
         "• Slow-healing cuts or infections\n"
         "• Tingling in hands or feet (neuropathy)\n\n"
         "**Tip:** Annual screening is recommended from age 35, or earlier with risk factors."),
        ("🥗 Dietary Guidelines",
         "**Favour:**\n"
         "• Non-starchy vegetables (broccoli, spinach, peppers)\n"
         "• Legumes, lentils, chickpeas\n"
         "• Whole grains (oats, brown rice, quinoa)\n"
         "• Lean proteins (fish, chicken, tofu)\n"
         "• Healthy fats (olive oil, avocado, nuts)\n\n"
         "**Limit:**\n"
         "• Refined carbs and white bread\n"
         "• Sugary drinks (sodas, fruit juices)\n"
         "• Ultra-processed snacks\n"
         "• Saturated fats and trans fats"),
        ("🏃 Exercise Prescription",
         "Physical activity is one of the most powerful diabetes-prevention and management tools:\n\n"
         "• **150 min/week** moderate aerobic (brisk walk, cycling, swimming)\n"
         "• **2–3 sessions/week** resistance training (improves insulin sensitivity)\n"
         "• Break up long sitting periods every 30 minutes\n"
         "• Even a 10-minute walk after meals reduces post-meal glucose spikes by ~22%\n\n"
         "Start low, go slow — consistency matters more than intensity."),
        ("💊 Blood Sugar Targets",
         "| Measure | Normal | Pre-Diabetes | Diabetes |\n"
         "|---|---|---|---|\n"
         "| Fasting glucose | < 100 mg/dL | 100–125 | ≥ 126 |\n"
         "| 2-hr post-meal | < 140 mg/dL | 140–199 | ≥ 200 |\n"
         "| HbA1c | < 5.7% | 5.7–6.4% | ≥ 6.5% |\n\n"
         "HbA1c reflects 3-month average glucose — it's the gold standard for monitoring."),
        ("💧 Hydration & Sleep",
         "**Water:** Staying well-hydrated helps kidneys flush excess glucose. Aim for **2–2.5 L/day** (more if active). Avoid sugary drinks.\n\n"
         "**Sleep:** 7–9 hours of quality sleep is essential. Short sleep:\n"
         "• Raises cortisol (elevates glucose)\n"
         "• Increases ghrelin (hunger hormone)\n"
         "• Reduces insulin sensitivity\n\n"
         "Even one week of poor sleep measurably impairs glucose metabolism in healthy adults."),
    ]

    for i, (title, content) in enumerate(info_blocks):
        with cols[i % 2]:
            with st.expander(title, expanded=(i < 2)):
                st.markdown(content)

    st.markdown("---")
    st.markdown('<div class="section-label">Daily Health Checklist</div>', unsafe_allow_html=True)
    checklist = [
        "💧 Drink 2+ litres of water",
        "🚶 Move for at least 30 minutes",
        "🥗 Eat at least 5 portions of vegetables",
        "😴 Get 7–8 hours of sleep",
        "🧘 Take 5 minutes for mindfulness or deep breathing",
        "🚭 Avoid smoking and limit alcohol",
        "🍬 Limit added sugar to < 25g (women) / < 36g (men)",
        "📊 If diabetic: check blood glucose as prescribed",
    ]
    c_a, c_b = st.columns(2)
    for j, item in enumerate(checklist):
        (c_a if j % 2 == 0 else c_b).checkbox(item, key=f"chk_{j}")
